# ADI-GRUPO4

- Sera necessario atualizar o caminho dos csv reader.